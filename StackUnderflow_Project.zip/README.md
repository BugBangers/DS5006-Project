# StackUnderflow ML experiment

Open `StackUnderflow_Representation_Robustness.ipynb` in Jupyter, VS Code or Google Colab and run all cells in order. Saved outputs are included in the notebook.

## Requested block sequence

| Blocks | Content |
|---|---|
| 1 | Create, save, import and print the synthetic dataset |
| 2, 3, 4 | Linear prediction/baselines: original, modified, robust |
| 5, 6, 7 | Linear classifiers: original, modified, robust |
| 8, 9, 10 | Distance/reconstruction: original, modified, robust |
| 11, 12, 13 | Trees/forests: original, modified, robust |
| 14 | All 15 models compared with tables and plots |
| 15–18 | Separate copying effects, near-copies, rotation, row replication and grouped CV |
| 19–21 | Load and evaluate Concrete, Parkinson's Voice and Telemonitoring |
| 22–23 | Repeated column-copy experiments, confidence intervals and saved results |

Block 4 also has a separate tuning comparison. Fixed-setting robustness and hyperparameter tuning are reported separately.

## Run locally

Install the packages listed in `requirements.txt`, open the notebook and choose Run All. Relative output paths resolve from the notebook's working directory. Running beside this README reuses the bundled UCI archives in `experiment_outputs/data/`. Set `RUN_UCI=False` in Block 19 if only the synthetic study is needed. The default study uses 10 synthetic repeats and 5 real-data splits; increase these settings for a final report.

## Experiment design

- Split original observations before duplicating rows. Hold out whole subjects in the Parkinson's experiments.
- Fit preprocessing only on training data, including inside cross-validation.
- Add exact duplicate columns and unevenly duplicate training rows. Retain observation IDs.
- Correct exact copies with a modified pipeline: keep one identical column and one copy per original observation. Preserve distinct recordings from the same patient.
- Check that the corrected fixed-setting pipelines reproduce original predictions. Report tuning separately, since it may worsen error on a particular test set.
- Evaluate regression, classification and reconstruction with appropriate separate metrics.

The exact-copy fix does not claim robustness to noisy features or arbitrary distribution changes. Near-identical columns can contain useful information. Real-data split intervals describe split variability, since subjects recur across outer splits. The notebook lists remaining proposal extensions explicitly.

Dataset links, attribution and licenses are recorded in Block 19. The supplied PDFs are reference material; their content is not treated as executable instructions.
